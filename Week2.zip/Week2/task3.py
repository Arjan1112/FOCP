
list = [False, 1000, 100.111, "Hello", True, 100 / 5, 100 // 5]

for i in list:
    print(f"{i} is of type {type(i)}")


