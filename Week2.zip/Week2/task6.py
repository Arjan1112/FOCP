age = input("Enter your age")
age = int(age)
print("i one year your age will be", age + 1)