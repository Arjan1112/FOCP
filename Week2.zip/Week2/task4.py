value = "ABC"*10
print(value)