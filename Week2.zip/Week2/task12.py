surname = "Palin"
tenth_letter = surname[9]

print("Tenth letter is",tenth_letter)

# IndexError: string index out of range