surname = "Palin"
sliced = surname[:-1]

print("Surname except the last character is",sliced)