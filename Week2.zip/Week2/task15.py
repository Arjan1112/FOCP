primes = [2,3,5,7,11,13,17,19,23,29]

first_four = primes[:4]

print("The first four prime numbers are:", first_four)