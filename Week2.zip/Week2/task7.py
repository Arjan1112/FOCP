comment = "I would have \"thought\" you knew better!"
print(comment)
