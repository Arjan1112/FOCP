total = 98.2
count = 5

average = total / count

print("Average is ", average)
