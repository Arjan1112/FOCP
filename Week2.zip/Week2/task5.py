age = input("Enter your age")
print("i one year your age will be", age + 1)

# Shows an error can only concatenate str (not "int") to str