names = ["Harry", "Tom", "Tim", "Bill", "Grame"]

# To insert new names

new_names = ["Mark", "Jacob"]

names[-1:-1] = new_names

print("Updated names list:", names)