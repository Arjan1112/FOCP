surname = "Palin"
sliced = surname[1:]

print("all of the characters of the ‘surname’ except the first character is", sliced)