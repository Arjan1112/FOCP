surname = "Palin"
third_letter = surname[2]

print("Third letter is",third_letter)