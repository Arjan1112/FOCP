#Try inputting the following code and examine the results.
total = 100
print("The total is", total)

#Try inputting the following code and examine the results.
total = total + 99
print("The total is now", total)

#Example part 1
total += 99
print("the total now ", total)

#TASK: Try inputting the following code, but replace each of the assignment expressions with the equivalent augmented assignment.
total = total - 1
print("The total is", total)

total = total * 4
print("The total is", total)
total = total / 2
print("The total is", total)